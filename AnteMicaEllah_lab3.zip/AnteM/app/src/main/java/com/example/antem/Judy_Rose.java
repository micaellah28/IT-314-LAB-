package com.example.antem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Judy_Rose extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_judy_rose);
    }
}